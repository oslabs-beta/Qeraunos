import React from 'react';
import UserCards from '../container/UserCards';

function Team() {
  return (
    <div>
      <h2> TEAM</h2>
      <UserCards />
    </div>
  );
}

export default Team;
